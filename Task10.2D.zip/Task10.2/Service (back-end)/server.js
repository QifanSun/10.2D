const express = require("express");
const bodyParser = require("body-parser");
const cors = require('cors');
const { Task } = require("./models");

const mongoose = require("mongoose");
const { static } = require("express");
// connect
// mongodb://username:password@host:port/database
//mongoose.connect("mongodb://sunqifa@deakin.edu.au:sqf0617.@localhost:27017/db", {
mongoose.connect("mongodb://localhost:27017/db", {
  useCreateIndex: true,
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(static("public"));
app.use(cors()); // 

// add
app.post("/api/task", async (req, res) => {
  const { body: reqBody } = req;
  const { title, task1, description, date, master, reward, number } = reqBody;

  try {
    const task = await Task.create({ title, task1, description, date, master, reward, number });
    // Return
    res.send(task);
  } catch (error) {
    const err = error.errors;
    if (err) {
      let messages = [];
      for (let key in err) {
        messages.push(err[key].message);
      }
      return res.status(500).send({ messages: messages.join("-------") });
    }
  }
});

// task list
app.get('/api/task', async (req, res) => {
  try {
    const taskList = await Task.find();
    res.send(taskList);
  } catch (error) {
    const err = error.errors;
    if (err) {
      let messages = [];
      for (let key in err) {
        messages.push(err[key].message);
      }
      return res.status(500).send({ messages: messages.join("-------") });
    }
  }
})

// delete task
app.post('/api/delete_task', async (req, res) => {
  try {
    const { id } = req.body;
    const { ok } = await Task.deleteOne({ _id: id });
    if (ok) {
      res.send({ code: 0, message: 'delete success' });
    } else {
      res.send({ code: 1, message: 'delete failed' });
    }
  } catch (error) {
    const err = error.errors;
    if (err) {
      let messages = [];
      for (let key in err) {
        messages.push(err[key].message);
      }
      return res.status(500).send({ messages: messages.join("-------") });
    }
  }
})

// search task
app.post('/api/search_task', async (req, res) => {
  try {
    const { date, title } = req.body;
    const result = await Task.find({
      $or: [
        { title: { $regex: title } },
        { date },
      ]
    });
    res.send(result);
  } catch (error) {
    const err = error.errors;
    if (err) {
      let messages = [];
      for (let key in err) {
        messages.push(err[key].message);
      }
      return res.status(500).send({ messages: messages.join("-------") });
    }
  }
})
app.listen(3001, () => {
  console.log("http://localhost:3001");
});
