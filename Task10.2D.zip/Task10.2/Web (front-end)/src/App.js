import React, { useState } from 'react';
import './App.css';

import CreateTask from './components/CreateTask';
import TaskList from './components/TaskList';

function App () {
  const [currentIndex, setCurrentIndex] = useState(0);
  return (
    <div className="App">
      <ul className="nav-group">
        <li className="nav-item" onClick={() => setCurrentIndex(0)}>create task</li>
        <li className="nav-item" onClick={() => setCurrentIndex(1)}>task list</li>
      </ul>
      <div>
        {
          currentIndex === 0 ? <CreateTask /> : null
        }
        {
          currentIndex === 1 ? <TaskList /> : null
        }
      </div>
    </div>
  );
}

export default App;
