import React, { useState } from 'react';
import './index.css';
import axios from 'axios';

function CreateTask () {
  const [task1, setTask1] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');
  const [master, setMaster] = useState('');
  const [reward, setReward] = useState('');
  const [number, setNumber] = useState('');

  const saveData = () => {
    console.log(title, task1, description, date, master, reward, number)
    const postData = {
      title,
      task1,
      description,
      date,
      master,
      reward,
      number
    }
    axios.post('http://localhost:3001/api/task', postData).then(response => {
      console.log(response);
      if (response.status === 200) {
        alert('add data success');
        window.location.href = '/'
      }
    })
  }
  return (
    <div className="App">
      <div className="title">New Requester Task <span>Worker Task</span> </div>
      <div className="f1">
        <span className="input-title">Select Task Type</span>
        <label>
          <input type="radio" value="0" name="task1" onClick={(e) => setTask1(e.target.value)} />
          Choice Task
        </label>
        <label>
          <input type="radio" value="1" name="task1" onClick={(e) => setTask1(e.target.value)} />
          Decision-Making Task
        </label>
        <label>
          <input type="radio" value="2" name="task1" onClick={(e) => setTask1(e.target.value)} />
          Sentence-Level Task
        </label>
      </div>
      <div className="title">Describe your task to Workers</div>
      <div className="f1">
        <span className="input-title">Title</span>
        <input type="text" placeholder="Enter task title" value={title} onChange={(event) => { setTitle(event.target.value) }} />
      </div>
      <div className="f1">
        <span className="input-title">Description</span>
        <input type="text" placeholder="Enter task description" value={description} onChange={(event) => setDescription(event.target.value)} />
      </div>
      <div className="f1">
        <span className="input-title">Expiry Date</span>
        <input type="date" value={date} onChange={(event) => setDate(event.target.value)} />
      </div>
      <div className="title">Setting up your Task</div>
      <div className="f2">
        <p>This section is designed based on the type of the task</p>
        <p>It could be developed by conditional rendering</p>
      </div>
      <div className="title">Worker Requirement</div>
      <div className="f1">
        <span className="input-title">require Master Workers</span>
        <label>
          <input type="radio" value="0" name="master-radio" onClick={(e) => setMaster(e.target.value)} />
          Yes
        </label>
        <label>
          <input type="radio" value="1" name="master-radio" onClick={(e) => setMaster(e.target.value)} />
          No
        </label>
      </div>
      <div className="f1">
        <span className="input-title">Reward per response</span>
        <input type="text" value={reward} onChange={(event) => setReward(event.target.value)} />
      </div>
      <div className="f1">
        <span className="input-title">Number of workers</span>
        <input type="text" value={number} onChange={(event) => setNumber(event.target.value)} />
      </div>
      <div className="save">
        <button className="save-btn" onClick={saveData}>Save</button>
      </div>
    </div>
  );
}

export default CreateTask;
